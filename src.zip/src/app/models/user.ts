export class User {

    id?: string;
    name?:string;
    email?: string;
    password?: string;
    phone?: number;
    token?:string;
   
}
