import { Action } from '@ngrx/store';
import {Product} from '../../models/product';



export const LIST_PRODUCTS = '[Products] Fetch Recipes';
export const ADD_PRODUCTS = '[Products] Add Recipe';
export const UPDATE_PRODUCTS = '[Products] Update Recipe';
export const DELETE_PRODUCTS = '[Products] Delete Recipe';
export const LIST_DATA_SUCCESS='[Products] List Success';


export class ListProducts implements Action {
  readonly type = LIST_PRODUCTS;
}

export class AddProducts implements Action {
  readonly type = ADD_PRODUCTS;

  constructor(public payload: Product) {}
}

export class UpdateProducts implements Action {
  readonly type = UPDATE_PRODUCTS;

  constructor(public payload: { index: number; newProduct: Product }) {}
}

export class DeleteProducts implements Action {
  readonly type = DELETE_PRODUCTS;

  constructor(public payload: number) {}
}


  export class ListDataSucess implements Action {
    readonly type = LIST_DATA_SUCCESS;
    constructor(public payload: Product[]) {}
  }

 


export type ProductsActions =
  | ListProducts
  | AddProducts
  | UpdateProducts
  | DeleteProducts
  | ListDataSucess;

