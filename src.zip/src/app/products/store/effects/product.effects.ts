import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { HttpClient } from '@angular/common/http';
import { switchMap, map,  mergeMap } from 'rxjs/operators';

import { ListDataSucess, LIST_PRODUCTS, ListProducts } from '../actions/product.action';
import { Product } from '../../models/product';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import {ProductService} from '../../services/product.service';
@Injectable()
export class ProductEffects {

    constructor(
        private actions: Actions,
        private productService: ProductService,
        private router: Router,
      ) {}


      @Effect({dispatch: true})
      ListProducts: Observable<any> =  this.actions.pipe(
                ofType(LIST_PRODUCTS),
                map((action: ListProducts) => action),
                mergeMap(payload => {
                    return this.productService.getAll().pipe(
                        map((data) => new ListDataSucess(data)));
                }));




 

  
}
