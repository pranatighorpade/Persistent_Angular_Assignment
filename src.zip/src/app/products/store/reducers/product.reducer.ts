import { Product } from '../../models/product';
import { LIST_PRODUCTS, LIST_DATA_SUCCESS, ProductsActions }  from '../actions/product.action';

export interface State {
  products: Product[];
}

const initialState: State = {
    products: []
};



export function productReducer(
  state = initialState,
  action: ProductsActions
)

{
    console.log(action);
    
  switch (action.type) {
    
    case LIST_PRODUCTS:
      return {
        ...state,
        products: [...state.products]
      };
      case LIST_DATA_SUCCESS: {
        console.log('in data_load', action, state);
        return {
          products: action.payload,
          message: null
        };
      }
     default:
      return state;
  }
}
