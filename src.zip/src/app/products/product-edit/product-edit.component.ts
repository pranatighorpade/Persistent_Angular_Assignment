import { Component, OnInit } from '@angular/core';
import { Product } from '../models/product';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { ProductService } from '../services/product.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-product-edit',
  templateUrl: './product-edit.component.html',
  styleUrls: ['./product-edit.component.scss']
})
export class ProductEditComponent implements OnInit {

  id: number;
  product: Product;
  editform: FormGroup;
  
  constructor(
    public productService: ProductService,
    private route: ActivatedRoute,
    public fb: FormBuilder,
    private router: Router
  ) { }
  
  ngOnInit(): void {
    this.id = this.route.snapshot.params['productId'];
    this.productService.getById(this.id).subscribe((data: Product)=>{
      this.product = data;
    });
    
    this.editform = this.fb.group({
      productName: [''],
      description: [''],
      price: [''],
      quantity: [''],    
    })
  }
   /*  this.form = new FormGroup({
      title: new FormControl('', [Validators.required]),
      body: new FormControl('', Validators.required)
    });
  }

  get f(){
    return this.form.controls;
  } */
     
  submit(){
    console.log(this.editform.value);
    this.productService.update(this.id, this.editform.value).subscribe(res => {
         console.log('Product updated successfully!');
         this.router.navigateByUrl('/product');
    })
  }
}